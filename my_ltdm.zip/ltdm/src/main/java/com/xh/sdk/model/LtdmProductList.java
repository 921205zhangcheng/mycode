package com.xh.sdk.model;

import java.util.Date;

public class LtdmProductList {
	
	
	private int id;
	private String spNumber;
	private String moContent;
	private String serviceType;
    private String payType;
	private String prov;
	private String dayLimit;
	private String feevalue;
	private String synUrl;
	private String mLimit;
	private String company;
	private String isuse;
	private String havetd;
	private String productName;
	private String xxmassages;
	private Date payaddtime;
	private String companyId;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSpNumber() {
		return spNumber;
	}
	public void setSpNumber(String spNumber) {
		this.spNumber = spNumber;
	}
	
	public String getSynUrl() {
		return synUrl;
	}
	public void setSynUrl(String synUrl) {
		this.synUrl = synUrl;
	}
	public String getPayType() {
		return payType;
	}
	public void setPayType(String payType) {
		this.payType = payType;
	}
	
	public String getFeevalue() {
		return feevalue;
	}
	public void setFeevalue(String feevalue) {
		this.feevalue = feevalue;
	}
	public String getMoContent() {
		return moContent;
	}
	public void setMoContent(String moContent) {
		this.moContent = moContent;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getProv() {
		return prov;
	}
	public void setProv(String prov) {
		this.prov = prov;
	}
	public String getDayLimit() {
		return dayLimit;
	}
	public void setDayLimit(String dayLimit) {
		this.dayLimit = dayLimit;
	}

	public String getMLimit() {
		return mLimit;
	}
	public void setMLimit(String mLimit) {
		this.mLimit = mLimit;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getIsuse() {
		return isuse;
	}
	public void setIsuse(String isuse) {
		this.isuse = isuse;
	}
	public String getHavetd() {
		return havetd;
	}
	public void setHavetd(String havetd) {
		this.havetd = havetd;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getmLimit() {
		return mLimit;
	}
	public void setmLimit(String mLimit) {
		this.mLimit = mLimit;
	}
	public String getXxmassages() {
		return xxmassages;
	}
	public void setXxmassages(String xxmassages) {
		this.xxmassages = xxmassages;
	}
	public Date getPayaddtime() {
		return payaddtime;
	}
	public void setPayaddtime(Date payaddtime) {
		this.payaddtime = payaddtime;
	}
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	

}
