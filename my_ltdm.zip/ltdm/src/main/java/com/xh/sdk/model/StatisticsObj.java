package com.xh.sdk.model;

public class StatisticsObj {
	
	private String tableName;
	
	private String productId;
	
	private String codeType;
	
	private String yystype;
	
	private String appId;

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getCodeType() {
		return codeType;
	}

	public void setCodeType(String codeType) {
		this.codeType = codeType;
	}

	public String getYystype() {
		return yystype;
	}

	public void setYystype(String yystype) {
		this.yystype = yystype;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}
	
	
	
	
	
	

}
