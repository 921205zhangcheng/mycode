package com.xh.sdk.model;

import java.util.Date;

public class LtdmOldUser {

	private int id;

	private String phone;

	private String prov;

	private String company;

	private String srcNum;

	private String smscontent;

	private String serviceType;
	private String productName;
	private String feevalue;
	private String statu;

	private String firsttime;
	private String endtime;
	
	private String xdtimes;

	private String isuse;
	private String errorCode;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirsttime() {
		return firsttime;
	}

	public void setFirsttime(String firsttime) {
		this.firsttime = firsttime;
	}

	public String getEndtime() {
		return endtime;
	}

	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}

	
	
	
	public String getXdtimes() {
		return xdtimes;
	}

	public void setXdtimes(String xdtimes) {
		this.xdtimes = xdtimes;
	}

	public String getIsuse() {
		return isuse;
	}

	public void setIsuse(String isuse) {
		this.isuse = isuse;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getProv() {
		return prov;
	}

	public void setProv(String prov) {
		this.prov = prov;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getSrcNum() {
		return srcNum;
	}

	public void setSrcNum(String srcNum) {
		this.srcNum = srcNum;
	}

	public String getSmscontent() {
		return smscontent;
	}

	public void setSmscontent(String smscontent) {
		this.smscontent = smscontent;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getFeevalue() {
		return feevalue;
	}

	public void setFeevalue(String feevalue) {
		this.feevalue = feevalue;
	}

	public String getStatu() {
		return statu;
	}

	public void setStatu(String statu) {
		this.statu = statu;
	}


}
