package com.xh.sdk.model;

public class LtdmProductInfo {
	
	
	private int id;

	private String name;


	private String payType;


	private String spnumber;
	
	private String mocontent;

	private String feevalue;
	
	private String serviceType;

	private String mtcontent;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPayType() {
		return payType;
	}

	public void setPayType(String payType) {
		this.payType = payType;
	}

	public String getSpnumber() {
		return spnumber;
	}

	public void setSpnumber(String spnumber) {
		this.spnumber = spnumber;
	}

	public String getMocontent() {
		return mocontent;
	}

	public void setMocontent(String mocontent) {
		this.mocontent = mocontent;
	}

	public String getFeevalue() {
		return feevalue;
	}

	public void setFeevalue(String feevalue) {
		this.feevalue = feevalue;
	}


	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getMtcontent() {
		return mtcontent;
	}

	public void setMtcontent(String mtcontent) {
		this.mtcontent = mtcontent;
	}
	
	
	
	
	

}
